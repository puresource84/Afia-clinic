# Analysis — `dental.doctor.invite` silently swallows all reset-password errors

## Reproduction confirmed

Confirmed by direct code inspection:
- `afia_dental_core/wizard/doctor_invite.py:64-67` — the unconditional
  `try: user.action_reset_password() / except Exception: pass`.
- Odoo core's OWN `action_reset_password()`
  (`odoo/addons/auth_signup/models/res_users.py:171-181`, this Odoo
  18.0.20241206 build) already anticipates the "mail not configured" case
  itself and converts it to a clean, typed exception:

  ```python
  def action_reset_password(self):
      try:
          ...
          return self._action_reset_password(signup_type="reset")
      except MailDeliveryException as mde:
          if len(mde.args) == 2 and isinstance(mde.args[1], ConnectionRefusedError):
              raise UserError(_("Could not contact the mail server, please check "
                                 "your outgoing email server configuration")) from mde
          else:
              raise UserError(_("There was an error when trying to deliver your "
                                 "Email, please check your configuration")) from mde
  ```

This is the key finding: **Odoo core has already done the work of
distinguishing "mail delivery failed" from other failures** — it catches
the low-level `MailDeliveryException` itself and re-raises it as a clean
`UserError` with a user-facing message. That means the ONLY exception
type that can realistically reach `doctor_invite.py`'s `except` clause
for the intended "SMTP not configured" scenario is `odoo.exceptions.UserError`.
Anything else that escapes — `AttributeError`, `KeyError`,
`ValidationError` from `signup_prepare()`, a future Odoo-core regression,
an interaction with another installed module's own override of
`action_reset_password` — is, by construction, NOT the case this wizard's
except block was written to handle. Catching `Exception` broadly also
catches all of these identically and silently.

## Root cause

Overly broad exception type (`Exception` instead of the specific
`UserError` that Odoo core itself uses for this exact scenario), combined
with a `pass` that performs no logging whatsoever. Two independent
defects compounding each other:

1. **Type too broad**: should catch `UserError` (what Odoo core actually
   raises for the anticipated case), not `Exception` (which也 catches
   programming errors, data errors, and anything else).
2. **No logging on the caught path either**: even for the correctly
   anticipated `UserError` case, there's no `_logger` call — so there's no
   audit trail at all of "email wasn't sent, here's why," which would be
   useful for a clinic admin following up days later on "the doctor says
   they never got the email."

## Contributing factors

- The form view's own copy ("If outgoing email is configured...") shows
  the author was aware email might not send and designed the UX around
  that — the bug is that the code doesn't match the narrower intent the
  UI text implies.
- No test exists for this method at all prior to this bug (confirmed via
  `afia_dental_core/.spec/testing/test-cases.md` TC-33 through TC-35,
  written 2026-09-19, which flagged this exact gap).

## Impact / blast radius

Contained entirely to `dental.doctor.invite.action_grant_access()` — no
other method or module calls this wizard's method or depends on its
current swallow-everything behavior. No schema impact (no fields need to
change). Fixing this only makes previously-invisible failures visible; it
cannot break anything that currently works, because "currently works" for
the unexpected-failure case just means "currently invisible," never
"currently handled."

## Recommended fix

Narrow the `except` to `UserError` specifically (matching what Odoo core
actually raises for the anticipated mail-config case), log it at INFO
level so there's an audit trail without alarming anyone (it's an expected,
routine condition for a clinic without SMTP set up). Add a second,
separate `except Exception` clause below it that logs at ERROR level with
full traceback (`_logger.exception(...)`) for anything genuinely
unexpected — but still does NOT re-raise, preserving the current design
intent that a doctor's user account should be created successfully
regardless of email delivery problems (re-raising would roll back the
whole wizard transaction, undoing the account creation too, which is
worse than the current behavior for the common no-SMTP case).

## Alternatives considered

1. **Let ALL exceptions propagate (remove the try/except entirely).**
   Rejected: this would roll back the user creation whenever a clinic
   without outgoing mail configured tries to grant access — the single
   most common real-world case for a self-hosted Iraqi clinic that may
   not have SMTP set up, per this project's own steering docs. Breaks the
   documented, intended fallback UX.
2. **Catch only `MailDeliveryException`.** Rejected: Odoo core already
   converts that to `UserError` before it would reach this wizard's own
   try/except (see the core code above) — catching the lower-level
   exception type here would never actually match anything in practice on
   this Odoo version.
3. **Do nothing, just add a code comment explaining the risk.** Rejected:
   same reasoning as the previous bug in this project — a comment doesn't
   prevent the actual masking of real errors; the fix needs to change
   behavior, not just documentation.

Fix implemented per the "narrow + log both paths, never re-raise" option
above, in `fix.md`.
