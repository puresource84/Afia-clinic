# Bug Report — `dental.doctor.invite` silently swallows all reset-password errors

- **Bug ID**: afia_dental_core-doctor-invite-swallowed-exception
- **Status**: Open
- **Date reported**: 2026-09-20
- **Severity**: Medium (no data corruption, but hides real failures behind
  a false-success UI with zero log trace — makes support/debugging
  effectively impossible when it happens)
- **Odoo version**: 18.0 Community Edition
- **Environment**: Reproducible in source across all environments — code-level
  issue, not environment-specific.
- **Module(s) affected**: `afia_dental_core` (`wizard/doctor_invite.py`)

## Business process impact

`dental.doctor.invite` is the ONLY sanctioned way to grant a dentist/staff
member Odoo login access in this suite (the manifest description calls it
a deliberate replacement for "the old silent/passwordless auto-user-creation
on every employee record" — i.e. this wizard exists specifically because
silent, unaccountable account creation was already identified as a past
problem once). It is used by the Clinic Manager/Administrator role
whenever onboarding a new dentist or staff member.

## User role affected

Clinic Manager / Clinic Administrator (whoever has access to grant system
access to employees).

## Business scenario / data conditions

Every time `action_grant_access()` is called: it always creates the
`res.users` record first (this part is not in question — it's fine), then
unconditionally tries `user.action_reset_password()` inside a bare
`try: ... except Exception: pass`.

```python
# afia_dental_core/wizard/doctor_invite.py:64-67
try:
    user.action_reset_password()
except Exception:
    pass
```

The comment above this block, and the form view's own text ("If outgoing
email is configured, a password-reset email was also sent"), make clear
the INTENDED case being handled is "clinic has no SMTP configured yet" —
a legitimate, expected, non-error condition for a self-hosted single-clinic
install that may not have set up outgoing mail. But `except Exception:
pass` catches everything, not just that one case: a broken mail template,
a corrupted partner record, a permission problem, an unrelated
`KeyError`/`AttributeError` from a future refactor of
`action_reset_password` in Odoo core or another installed module's
override of it — all of these are hidden identically, with no
`_logger` call, no chatter note, nothing. The wizard always reports
success (shows the temp password, sets `state='done'`) regardless of
which of these happened.

## Multi-company / localization impact

None specific — the swallowed-exception behavior is identical regardless
of company or language.

## Related modules / integrations

- `afia_dental_core/wizard/doctor_invite.py` (the bug)
- `afia_dental_core/wizard/doctor_invite_views.xml` (the form text that
  documents the intended fallback case)
- Odoo core `res.users.action_reset_password()` (the call being wrapped)

## Expected vs actual behavior

**Expected**: the wizard should silently tolerate the specific,
anticipated "no outgoing mail configured" condition (matching the UI copy
already promising this), but any OTHER unexpected failure from
`action_reset_password()` should at minimum be logged server-side (so it's
discoverable during support/debugging), and ideally should not be
indistinguishable from the "mail not configured" case if there's a way to
tell them apart.

**Actual**: every exception, expected or not, is silently discarded with
no trace anywhere. A clinic admin who hits a real, unexpected failure has
no way to know anything went wrong beyond "the doctor says they never got
an email" days later — and support has nothing to go on, because nothing
was ever logged.

## Reproduction steps

1. Read `wizard/doctor_invite.py` lines 40-69 — the bare
   `except Exception: pass` is unconditional, confirmed by inspection
   (no exception-type filter, no logging call inside the except block).
2. To reproduce the masking effect concretely: temporarily patch
   `action_reset_password` to raise an unrelated exception (e.g.
   `RuntimeError('simulated unrelated failure')`) and call
   `action_grant_access()` — observe the wizard still reports
   `state='done'` with a temp password shown, and nothing appears in the
   server log.

## Logs / tracebacks

None available by design — that's precisely the bug. No traceback has
ever been captured for a real occurrence of this because the except
clause discards it before it can be logged.
