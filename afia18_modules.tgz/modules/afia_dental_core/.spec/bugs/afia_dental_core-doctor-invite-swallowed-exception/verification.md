# Verification — `dental.doctor.invite` silently swallows all reset-password errors

## Checks completed now (static, no live Odoo instance touched)

| Check | Result |
|---|---|
| `doctor_invite.py`, the new `test_doctor_invite.py`, and updated `tests/__init__.py` compile cleanly (`python3 -m py_compile`) | **Pass** |
| Confirmed against this project's actual Odoo 18.0.20241206 build (`auth_signup/models/res_users.py`) that `action_reset_password()` raises `UserError` for the mail-delivery/config case, not a raw `MailDeliveryException` — the fix's `except UserError` branch is verified correct against the real installed Odoo version, not assumed from general knowledge | **Pass** |
| Grep for other callers of `action_reset_password`/`doctor.invite`/`doctor_invite` across `launch_sprint1_addons` | Only `afia_dental_core`'s own wizard and its views/tests/security CSV reference `dental.doctor.invite`. No other module calls `action_grant_access()` or depends on its previous swallow-everything behavior. | **Pass** |
| No schema/view/security changes made | Confirmed — only the wizard's Python method body changed | **Pass** (by design) |

## Related finding surfaced during this verification (not fixed here — separate scope)

`dental_ux_fixes/wizards/clinic_user_wizard.py:158-162` has its OWN
direct call to `new_user.action_reset_password()`, with **no try/except
at all** — if a clinic has no outgoing mail configured, this would raise
an uncaught `UserError` and roll back that entire staff-account-creation
wizard (a worse outcome than the bug just fixed here: total failure
instead of silent swallowing). This is a different module, a different
wizard, and wasn't part of the reported bug — flagging it as a candidate
for its own `/odoo-bug-create` rather than fixing it under this bug's
scope, per the "never touch unrelated modules" rule.

## Checks that require Manhel's live instance (pending)

1. **Module upgrade applies cleanly** — upgrade `afia_dental_core` on
   `db_odoo`, expect no errors in the log.
2. **Regression tests pass** — run all four tests in
   `test_doctor_invite.py` against a disposable test DB; the two new ones
   specifically prove the wizard still completes successfully whether
   the mocked failure is the expected `UserError` or an unexpected
   `RuntimeError`.
3. **Live no-SMTP case** — grant access to a real test employee on the
   dev instance (which currently has no outgoing mail server configured,
   per prior session history) and confirm: (a) the wizard still shows
   "Access granted" with a temp password, exactly as before, and (b) a
   new `INFO`-level log line appears
   (`dental.doctor.invite: reset-password email not sent for ...`)
   where previously there was nothing.
4. **No regression on the duplicate-login guard** — `test_grant_access_rejects_duplicate_login`
   (pre-existing, unaffected by this change) still passes.

## Residual risk

Low. This is a pure exception-handling change with no schema, security,
or cross-module impact, and both new tests explicitly prove the fix
preserves the original non-fatal behavior for BOTH the expected and
unexpected failure cases — the only change is that failures now leave a
log trace. The flagged `clinic_user_wizard.py` finding is a separate,
arguably higher-severity issue (total failure vs. silent swallow) worth
raising as its own bug next.

## Status

**Code-complete, statically verified against the real installed Odoo core
source. Live-instance verification (items 1–4 above) pending Manhel
running the module upgrade on `db_odoo`.** Marking as "Fix Implemented —
Awaiting Live Verification," matching the previous bug's convention.
