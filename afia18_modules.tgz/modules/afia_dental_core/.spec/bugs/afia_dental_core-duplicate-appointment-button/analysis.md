# Analysis — Duplicate `action_view_appointments` / `appointment_count` override

## Reproduction confirmed

Confirmed by direct code inspection (both files read in full):

- `afia_dental_core/models/res_partner.py:27-28` — `appointment_count = fields.Integer(compute='_compute_appointment_count')`, batched implementation at lines 56-63.
- `dental_ux_fixes/models/res_partner_smart_buttons.py:7-17` — same field name, redeclared with `compute='_compute_appointment_count'` pointing at ITS OWN method (also named `_compute_appointment_count`, same name reused inside the second `_inherit` class), which loops `search_count()` per record.
- `action_view_appointments` defined at `afia_dental_core/models/res_partner.py:127-143` and again at `dental_ux_fixes/models/res_partner_smart_buttons.py:19-32`, no `super()` call in either.

## Root cause (file:line evidence)

**Odoo mechanism**: when two `_inherit = 'res.partner'` extension classes
in different modules both declare a field with the same name, or both
define a method with the same name, the class actually used at runtime
follows Odoo's MRO, which is built in **module load order** — determined
by the dependency graph (`depends` in `__manifest__.py`), not file
alphabetical order or install order alone. `dental_ux_fixes/__manifest__.py:10`
lists `afia_dental_core` in `depends`, meaning `dental_ux_fixes` is
guaranteed to load strictly after `afia_dental_core`. Its class
definition is applied on top, so its field/method wins.

**Contributing factor #1 — performance regression**: `afia_dental_core`'s
`_compute_appointment_count` (res_partner.py:56-63) was deliberately
written to use one `_read_group()` call for the whole recordset — the
code comment there explicitly frames this as an optimization over a
per-record `search_count()`. `dental_ux_fixes`'s redefinition
(res_partner_smart_buttons.py:12-17) does exactly the per-record
`search_count()` the original was written to avoid. Because it's the
version that actually runs, the Patients list view (which computes
`appointment_count` for every visible row) currently pays an N+1 query
cost that a previous engineering decision explicitly tried to eliminate.
This is a real, live performance regression, not just theoretical.

**Contributing factor #2 — behavioral drift**: the two
`action_view_appointments` implementations differ in `context`:
`dental_ux_fixes`'s adds `search_default_patient_id: self.id` in addition
to `default_patient_id`; `afia_dental_core`'s does not. In practice this
is low-impact (the `domain` already filters to the patient, so the
search-default is redundant, not corrective) — but it's evidence the two
copies have already diverged once and could diverge again in a way that
does matter, since nothing enforces they stay identical except a code
comment asking future editors to remember.

## Blast radius across dependent modules

- Direct: `afia_dental_core`, `dental_ux_fixes` (the only two modules
  involved).
- Indirect: any module that calls `action_view_appointments` by name via
  a button `<button name="action_view_appointments" type="object".../>`
  in a view — confirmed via grep this method name is referenced only in
  `afia_dental_core`'s own `res_partner_views.xml` smart-button XML (the
  button XML doesn't care which Python class's method actually executes,
  since Odoo resolves it dynamically at call time — no view-layer changes
  needed regardless of which copy is kept).
- No model/schema impact — `appointment_count` is a non-stored compute
  field in both definitions, so there's no migration concern from
  changing which implementation is authoritative.

## Recommended fix

Delete the entire duplicated block in `dental_ux_fixes`
(`res_partner_smart_buttons.py`'s `appointment_count` field +
`_compute_appointment_count` + `action_view_appointments`), keep ONLY
`action_new_appointment` and `action_telegram_link` in that file (the two
methods genuinely unique to `dental_ux_fixes`). This:

- Restores the batched `_read_group()` compute as the one that actually
  runs (fixes the N+1 regression).
- Removes the dead-code/must-keep-in-sync-by-hand maintenance trap.
- Is the smallest possible change — no view XML changes needed (button
  `name="action_view_appointments"` still resolves correctly to the
  now-single implementation in `afia_dental_core`), no field/schema
  migration (non-stored compute field, nothing to migrate), no version
  bump risk beyond the two modules directly involved.
- If `dental_ux_fixes`'s slightly different `context` (the
  `search_default_patient_id` addition) is actually wanted, that one line
  can be added to `afia_dental_core`'s single remaining copy instead of
  keeping two full method bodies in sync.

## Alternatives considered

1. **Keep `dental_ux_fixes`'s copy, delete `afia_dental_core`'s.** Rejected:
   `afia_dental_core` is the foundation module — the canonical
   implementation of a *core* patient-record action belongs there, not in
   a UX/branding module (`dental_ux_fixes`'s own manifest describes itself
   as "Visual polish and user experience improvements," not business
   logic ownership). Keeping business logic in the foundation module also
   matches this project's own module-standards steering doc.
2. **Make `dental_ux_fixes` call `super()`.** Rejected as the primary fix:
   this would still leave two field/method definitions to maintain in
   parallel for no reason, just with `super()` wired up — more code than
   necessary for functionality that has no reason to differ. Deleting the
   duplicate is simpler and removes the maintenance trap entirely, per
   the "prefer the smallest change" rule — smallest in maintenance
   surface, not just line count.
3. **Do nothing, just document the pattern more clearly.** Rejected: the
   comment already documents it ("if you change one, change both") and
   that hasn't prevented the fields from actually diverging (the
   `search_default_patient_id` difference already happened). A comment is
   not a substitute for one source of truth.

Fix implemented per option 1 in `fix.md`.
