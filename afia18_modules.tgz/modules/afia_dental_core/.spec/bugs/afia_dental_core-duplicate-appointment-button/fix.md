# Fix — Duplicate `action_view_appointments` / `appointment_count` override

## Change summary

Removed the duplicate `appointment_count` field, `_compute_appointment_count`
method, and `action_view_appointments` method from `dental_ux_fixes`. The
single remaining implementation of both lives in `afia_dental_core`
(where the batched, performant compute already was). Carried over the
one genuine behavioral difference (`search_default_patient_id` in the
action's context) from the removed copy into the surviving one, so
end-user behavior is unchanged. `dental_ux_fixes` keeps only its two
genuinely unique methods (`action_new_appointment`, `action_telegram_link`).

## Files changed

- `launch_sprint1_addons/dental_ux_fixes/models/res_partner_smart_buttons.py`
  — removed `appointment_count` field, `_compute_appointment_count`,
  `action_view_appointments`; removed now-unused `api`/`fields` imports;
  added a comment pointing to this bug record for anyone who finds the
  method missing and wonders why.
- `launch_sprint1_addons/afia_dental_core/models/res_partner.py` —
  `action_view_appointments`'s context now includes
  `search_default_patient_id` (preserving the removed copy's behavior);
  comment updated to state this is now the single authoritative
  implementation, replacing the old "if you change one, change both"
  warning.
- `launch_sprint1_addons/afia_dental_core/__manifest__.py` — version
  `18.0.2.0.9` → `18.0.2.0.10`.
- `launch_sprint1_addons/dental_ux_fixes/__manifest__.py` — version
  `18.0.2.2.3` → `18.0.2.2.4`.
- `launch_sprint1_addons/afia_dental_core/tests/test_res_partner.py` —
  added two regression tests: `test_appointment_count_uses_batched_afia_dental_core_compute`
  and `test_action_view_appointments_single_definition`, both asserting
  via `__module__` introspection that these members resolve to
  `afia_dental_core`, not a shadowing redefinition elsewhere.

## Migration steps

None. `appointment_count` is a non-stored compute field in both the old
and new state — nothing to migrate at the database level. No view XML
changes needed: `res_partner_views.xml`'s button (`name="action_view_appointments"`)
and field reference (`name="appointment_count"`) resolve dynamically to
whichever Python member is registered, which is now unambiguous.

## Rollback plan

Revert the two model-file edits and the two manifest version bumps (a
single `git revert` of this commit once pushed). No data was touched, so
rollback is a pure code revert with zero DB-side cleanup required, at any
point (even after real clinics have upgraded).

## Deployment plan

1. Apply on the local dev instance (`db_odoo`) first: upgrade both
   `afia_dental_core` and `dental_ux_fixes` (Manhel runs this — no shell
   access to the Windows Odoo service from this environment).
2. Run the two new regression tests plus the existing
   `test_appointment_count_batched` test against a disposable test DB.
3. Manually click the "Appointments" smart button on a real patient
   record post-upgrade to confirm the list view still opens correctly
   with the right domain (see `verification.md`).
4. Once verified locally, run `python packaging/sync_to_repo.py` to bring
   `afia-clinic-repo` up to date, review the diff, and Manhel commits/pushes
   himself per standing project rule (no automated git commit/push to the
   public repo).
5. No App Store package rebuild is required as a hard dependency of this
   fix (both modules are `shared`), but the next scheduled
   `build_app_store_package.py --zip` run will naturally pick it up.

## Post-deploy monitoring checklist

- Confirm no `ParseError`/`AttributeError` on module upgrade (would
  indicate a view or code reference to the removed members was missed —
  the grep in `analysis.md` didn't find one, but worth watching the
  upgrade log once).
- Spot-check the Patients list view's query count (browser dev tools /
  Odoo's own query-count debug indicator in developer mode) on a page
  with several patients — should no longer show one
  `SELECT...dental_appointment...` per row.
- No user-facing announcement needed — this is an invisible internal
  fix with no behavior change for clinic staff.
