# Bug Report — Duplicate `action_view_appointments` / `appointment_count` override

- **Bug ID**: afia_dental_core-duplicate-appointment-button
- **Status**: Open
- **Date reported**: 2026-09-20
- **Severity**: Medium (silent behavioral/performance drift, not a crash — but affects the Patients "Appointments" smart button used by every clinic role on every patient record)
- **Odoo version**: 18.0 Community Edition (this project targets 18.0, not 19.0 — see steering docs)
- **Environment**: Reproducible in source across all environments (self-hosted, App Store, local dev) — this is a code-level module-load-order issue, not environment-specific.
- **Module(s) affected**: `afia_dental_core` (defines the original), `dental_ux_fixes` (defines the silently-winning override)

## Business process impact

The "Appointments" smart button on every patient's `res.partner` form is
used by Receptionist, Dentist/Hygienist, and Clinic Manager roles daily —
it's the primary way front-desk staff jump from a patient record to their
appointment history. Two modules independently define both the
`appointment_count` field (with different `compute` implementations) and
the `action_view_appointments` method (with different `context`/domain
details) on the same model. Whichever module Odoo loads last silently
wins for both — currently `dental_ux_fixes`, per its `depends` list
including `afia_dental_core`.

## User role affected

All internal roles that see a patient's form view (Receptionist, Dentist,
Hygienist, Clinic Manager) — the smart button is not role-restricted.

## Business scenario / data conditions

Reproducible on any patient record with one or more appointments, on any
database with both `afia_dental_core` and `dental_ux_fixes` installed
(which is every real deployment — `dental_ux_fixes` depends on
`afia_dental_core` and ships in the standard install set per
`afia-clinic-repo/README.md`'s recommended install order).

## Multi-company / localization impact

None specific to this bug — both implementations use the same
`patient_id` domain scoping, no company or translation differences
between the two copies.

## Related modules / integrations

- `afia_dental_core/models/res_partner.py` — original `appointment_count`
  (batched `_read_group`) and `action_view_appointments`.
- `dental_ux_fixes/models/res_partner_smart_buttons.py` — the version that
  actually runs at runtime; also defines `action_new_appointment` and
  `action_telegram_link` (not duplicated elsewhere, not in scope of this
  bug).

## Expected vs actual behavior

**Expected**: one authoritative implementation of `appointment_count` and
`action_view_appointments`; no two modules silently racing to define the
same field/method on the same model.

**Actual**:
1. `appointment_count` is defined TWICE. `afia_dental_core`'s version
   uses a single batched `_read_group()` call for the whole recordset
   (explicitly written that way per its own code comment: "One
   `read_group` for the whole recordset instead of a `search_count()`
   per record"). `dental_ux_fixes`'s redefinition uses a per-record
   `Apt.search_count(...)` in a loop — reintroducing the exact N+1 query
   pattern the original was written to avoid. Because `dental_ux_fixes`
   loads after `afia_dental_core`, ITS compute method is the one Odoo
   actually registers and runs.
2. `action_view_appointments` is defined TWICE with slightly different
   `context` (the `dental_ux_fixes` version also sets
   `search_default_patient_id`, `afia_dental_core`'s does not) — a real,
   if minor, behavioral difference between the two copies, not just
   duplicated code. The `dental_ux_fixes` copy wins at runtime because it
   has no `super()` call and loads later; the `afia_dental_core` copy is
   effectively dead code today, but stays in the codebase as a
   maintenance trap — a comment in `res_partner.py` literally says "if
   you change one, change both."

## Reproduction steps

1. Open any patient record with `>=1` appointment.
2. Click the "Appointments" smart button.
3. Observe the list view opens correctly (functionally fine right now —
   this is not a crash bug) — but confirm via code inspection (not just
   UI) that the method executing is `dental_ux_fixes`'s copy, e.g. by
   temporarily adding a distinguishing log line to each and reloading.
4. Separately, confirm the N+1 query pattern: enable SQL query logging,
   open a Patients list view with several patients each having multiple
   appointments, and count `SELECT ... FROM dental_appointment WHERE
   patient_id = ...` queries — expect one per visible patient row instead
   of one batched query for the page.

## Logs / tracebacks

None — this bug doesn't raise an exception. It's an established-by-code-reading
silent override, confirmed via the code comment in
`afia_dental_core/models/res_partner.py:127-134` that already documents
awareness of the duplication (self-admitted maintenance debt, not
previously formalized as a tracked bug).
