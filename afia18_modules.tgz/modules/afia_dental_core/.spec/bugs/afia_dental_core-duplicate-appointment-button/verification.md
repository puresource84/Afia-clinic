# Verification — Duplicate `action_view_appointments` / `appointment_count` override

## Checks completed now (static, no live Odoo instance touched)

| Check | Result |
|---|---|
| Both edited Python files + the new test file compile cleanly (`python3 -m py_compile`) | **Pass** |
| Grep for `action_view_appointments` / `_compute_appointment_count` across `launch_sprint1_addons` | Only `afia_dental_core/models/res_partner.py` defines them now; `dental_ux_fixes`'s copy is gone; no other live module references either name (only an `_excluded_old_dental_ux_fixes` snapshot, not live source) | **Pass** |
| Grep for `appointment_count` inside `dental_ux_fixes` broadly (not just the two removed members) | Two unrelated hits: `commission_report.py` (a separate SQL-view model, `dental.commission.report`, with its own unrelated `appointment_count` column) and its report view — confirmed by reading both, no relation to `res.partner`'s field, no conflict | **Pass** |
| `res_partner_views.xml`'s button (`name="action_view_appointments"`) and field (`name="appointment_count"`) resolve dynamically by name, not by import | No view XML change needed or made | **Pass** (by design, not a new check) |
| No schema/migration impact — field stays non-stored `compute=` in both before/after states | Confirmed by reading both field declarations before editing | **Pass** |

## Checks that require Manhel's live instance (not run yet — pending)

These need the actual `db_odoo` Windows Odoo service, which I don't have
shell access to — Manhel needs to run the module upgrade himself, same as
every other change this session:

1. **Module upgrade applies cleanly.** Upgrade both `afia_dental_core`
   and `dental_ux_fixes` on `db_odoo` (`-u afia_dental_core,dental_ux_fixes`
   or via Settings → Apps → Upgrade). Expect no `ParseError`/`AttributeError`
   in the log.
2. **Original reproduction no longer applies.** Open a patient record,
   click "Appointments" — should still open the correct list, scoped to
   that patient, exactly as before (no visible behavior change expected;
   this was an internal-only fix).
3. **Regression tests pass.** Run
   `test_appointment_count_uses_batched_afia_dental_core_compute` and
   `test_action_view_appointments_single_definition` (added to
   `afia_dental_core/tests/test_res_partner.py`) against a disposable
   test DB — both should pass now that the duplicate is removed, and
   would have FAILED against the pre-fix code (proving they're real
   regression guards, not tautologies).
4. **Query-count spot check.** With developer mode's query-count
   indicator (or SQL logging) on, open the Patients list view with
   several patients who each have multiple appointments — expect ONE
   batched query for the `appointment_count` column across the whole
   page, not one `search_count()`-style query per row.
5. **Neighboring feature regression.** Confirm `action_new_appointment`
   and `action_telegram_link` (the two methods that stayed in
   `dental_ux_fixes`) still work unchanged — they weren't touched, but
   worth a quick click-through since the file was edited.
6. **Multi-company / localization.** No company or translation-specific
   logic was touched; no separate check needed beyond #2 above on
   whichever company the test patient belongs to.

## Residual risk

Low. This is a pure Python-level deduplication with no schema, security,
or view changes, and the only distinguishing behavior between the two
former copies (`search_default_patient_id`) was explicitly preserved.
The main residual risk is the same class of bug recurring if a THIRD
module ever redefines `appointment_count` or `action_view_appointments`
on `res.partner` again — the two new regression tests are the guard
against that, but only if they're actually run before each release (no
CI runs them automatically yet — see `afia_dental_core/.spec/testing/ci-cd-integration.md`).

## Status

**Code-complete, statically verified. Live-instance verification (items
1–6 above) pending Manhel running the module upgrade on `db_odoo`.**
Marking as "Fix Implemented — Awaiting Live Verification" rather than
"Resolved" until those checks are actually run and reported back.
