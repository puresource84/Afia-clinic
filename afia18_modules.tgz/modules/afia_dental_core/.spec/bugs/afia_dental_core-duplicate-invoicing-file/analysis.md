# Analysis — duplicate invoicing file

## Root cause of the ORIGINAL confusion (mine, during triage)

The audit found two identical files and, by analogy with the
`action_view_appointments` bug fixed earlier today, assumed the same
"later-loaded module wins" shadowing pattern applied. That pattern
requires BOTH copies to actually be imported/registered with Odoo. A
check of `dental_ux_fixes/models/__init__.py` shows it deliberately does
NOT import `appointment_invoicing` — someone had already found and fixed
this exact duplication before, and left a clear comment explaining why
(the file used to live in `dental_ux_fixes`, was moved to
`dental_patient_flow` to break a circular-dependency problem — documented
separately in a comment in `dental_patient_flow/views/patient_flow_board.xml`
— and the leftover copy was intentionally excluded from import rather
than deleted, likely due to the same file-deletion sandbox limitation
encountered again today).

## Why this is real but lower severity

- Not a live shadowing bug: `dental_patient_flow`'s copy is the only one
  Odoo ever registers; `action_create_invoice`/`action_view_invoices`/
  `invoice_ids`/`invoice_count` on `dental.appointment` all resolve
  there, consistently, today.
- The risk is purely maintenance/confusion: a future developer editing
  `dental_ux_fixes`'s copy (not realizing it's dead) would waste time
  and never see their change take effect — exactly what nearly happened
  in this audit itself.
- A stale comment in `dental_ux_fixes/tests/test_smoke_flow.py` pointed
  at the wrong file for the UserError guard being tested — corrected.

## Fix

Could not delete the dead file (sandbox limitation, same one documented
in `packaging/README.md`). Instead: added an unmissable "DEAD CODE — NOT
IMPORTED" banner to the top of the file itself, updated the explanatory
comment in `dental_ux_fixes/models/__init__.py` to reference this audit,
and fixed the stale test comment. Functionally zero-risk — nothing
executable changed.

## Recommendation for Manhel

Delete `dental_ux_fixes/models/appointment_invoicing.py` by hand
whenever convenient — it's confirmed safe to remove entirely.
