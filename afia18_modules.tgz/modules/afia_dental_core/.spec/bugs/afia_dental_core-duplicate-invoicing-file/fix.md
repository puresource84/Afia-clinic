# Fix — duplicate invoicing file

## Changes

- `dental_ux_fixes/models/appointment_invoicing.py`: added a prominent
  dead-code banner comment; file content otherwise unchanged (still not
  imported).
- `dental_ux_fixes/models/__init__.py`: updated the explanatory comment.
- `dental_ux_fixes/tests/test_smoke_flow.py`: fixed a docstring that
  pointed at the wrong (dead) file for a UserError guard.
- `dental_ux_fixes/__manifest__.py`: version `18.0.2.2.5` → `18.0.2.2.6`.

No functional/model/view changes. `dental_patient_flow` (the live copy)
was not touched at all.

## Rollback

Revert the comment/banner edits. Zero risk.

## Deployment

Upgrade `dental_ux_fixes` on `db_odoo` whenever convenient (bundled with
the D2 upgrade already needed for that module). Optionally, Manhel can
delete `dental_ux_fixes/models/appointment_invoicing.py` by hand at any
time — confirmed safe, not required for this fix to be complete.
