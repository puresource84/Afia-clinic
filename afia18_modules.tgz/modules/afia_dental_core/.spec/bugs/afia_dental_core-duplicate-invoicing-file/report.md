# Bug Report — `appointment_invoicing.py` duplicated across two modules

- **Bug ID**: afia_dental_core-duplicate-invoicing-file
- **Status**: Fixed same session (documentation/cleanup — see correction below)
- **Severity**: Downgraded from Medium-High (initial audit estimate) to
  **Low** after investigation — see Analysis.
- **Modules**: `dental_patient_flow`, `dental_ux_fixes`
- **Found**: 2026-09-20 system audit, Domain D3

## Initial finding (from the audit)

`dental_patient_flow/models/appointment_invoicing.py` and
`dental_ux_fixes/models/appointment_invoicing.py` are byte-for-byte
identical files, both defining `_inherit = 'dental.appointment'` with the
same `invoice_ids` field (same M2M relation table name), `invoice_count`,
and three methods. The audit initially assumed both were live and that
`dental_ux_fixes`'s copy silently shadowed `dental_patient_flow`'s at
runtime (the same class of bug as the `action_view_appointments` and
`doctor_invite` fixes earlier today).

## Correction after investigation (see analysis.md)

That assumption was WRONG. `dental_ux_fixes/models/__init__.py` already
contains an explicit comment stating this file is intentionally NOT
imported — it is dead code, confirmed never executed. Only
`dental_patient_flow`'s copy is live. This is a real finding (a confusing,
duplicate, unused file sitting in the repo) but NOT a runtime shadowing
bug — severity downgraded accordingly.
