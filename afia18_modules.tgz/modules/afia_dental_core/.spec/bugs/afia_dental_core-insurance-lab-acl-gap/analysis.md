# Analysis — insurance/lab ACL gap

## Root cause

Both modules were built depending only on `afia_dental_core`, and their
authors used the simplest possible ACL row (`base.group_user`, full CRUD)
to get the module working, without ever tightening it to the role
hierarchy `afia_dental_core` itself already defines
(`security_groups.xml`: `group_dental_reception` ⊂ `group_dental_dentist`
⊂ `group_dental_manager`, via `implied_ids`). Every other clinical/business
model in `afia_dental_core`'s own baseline CSV follows a two-tier pattern:
`base.group_user` gets read-only (or no access) on sensitive fields,
`group_dental_manager` (or a matching business-role group) gets full CRUD.
These two modules simply never received that second pass.

## Fix chosen

Match the established pattern exactly, using
`afia_dental_core.group_dental_reception` as the elevated-access group
(not `group_dental_manager`) because: (a) it's the lowest tier in the
existing hierarchy, so granting it there means Receptionist, Dentist, AND
Clinic Administrator all get access automatically via `implied_ids`
cascading upward, matching Manhel's explicit 2026-07-29 confirmation that
Receptionist handles billing/payment tasks as normal practice in this
market; (b) `base.group_user` is demoted to read-only, not zero access,
so no currently-working read-only usage (e.g. a report or dashboard that
merely displays insurance/lab data to a broader audience) breaks.

## Blast radius

Contained to the two modules' own ACL files plus new test files. No
model, view, or business-logic changes. Considered whether any other
module reads/writes these models expecting `base.group_user`-level
access and found none via grep (`action_flow_invoice`,
`dental.lab.order`, `dental.claim`, `dental.policy`, `dental.insurer`
references are all either within these two modules or read-only display
contexts).

## Alternative considered and rejected

Granting to `group_dental_manager` only (admin-only) — rejected because
it would newly LOCK OUT receptionists and dentists from insurance/lab
tasks they can do today (even though today's access is accidental/blanket,
removing it entirely would be a functional regression, not just a
security tightening — violates "no risk of losing system intention").
