# Fix — insurance/lab ACL gap

## Change summary

- `dental_insurance/security/ir.model.access.csv`: demoted the three
  `base.group_user` rows (insurer/policy/claim) to read-only (`1,0,0,0`);
  added three new rows granting full CRUD to
  `afia_dental_core.group_dental_reception`.
- `dental_lab/security/ir.model.access.csv`: same pattern for
  `dental.lab.order`.
- Version bumps: `dental_insurance` 18.0.1.0.1 → 18.0.1.0.2,
  `dental_lab` 18.0.1.0.2 → 18.0.1.0.3.
- New test files (both modules had none before):
  `dental_insurance/tests/test_access_control.py`,
  `dental_lab/tests/test_access_control.py` — each proves a bare internal
  user can read but not write/create, and a reception-group user can do
  both.

## Migration steps

None — pure ACL row changes, no schema impact. Existing data unaffected;
only which users can write/create/delete changes.

## Rollback plan

Revert the two CSV files and manifest version bumps. No data touched.

## Deployment plan

1. Upgrade `dental_insurance` and `dental_lab` on `db_odoo`.
2. Run the new test files against a disposable test DB.
3. Confirm a demo receptionist/dentist account can still create/edit an
   insurance claim and a lab order (no functional regression).
4. Confirm a non-clinic internal user (if one exists on the instance)
   can no longer edit these records.
5. Sync to `afia-clinic-repo`, Manhel reviews/commits/pushes.

## Post-deploy monitoring

Watch for any `AccessError` reports from real clinic staff after
upgrade — would indicate a legitimate workflow needs a broader group
than `group_dental_reception` covers (unlikely given the cascading
hierarchy, but worth a day of attention).
