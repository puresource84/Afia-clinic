# Bug Report — `dental_insurance` and `dental_lab` grant full CRUD to every internal user

- **Bug ID**: afia_dental_core-insurance-lab-acl-gap
- **Status**: Open (fix implemented same session)
- **Date reported**: 2026-09-20 (found during the full-system audit)
- **Severity**: High
- **Odoo version**: 18.0 CE
- **Module(s) affected**: `dental_insurance`, `dental_lab`

## Business process impact

`dental.insurer`, `dental.policy`, `dental.claim` (insurance/financial
records) and `dental.lab.order` shipped with a single `ir.model.access.csv`
row each, granting full read/write/create/unlink to `base.group_user` —
every internal Odoo user, with no role restriction whatsoever. Any
employee added to the system for an unrelated reason (accounting,
inventory, HR) could read, edit, or delete insurance claims and lab
orders. This contradicts the role matrix `dental_clinical_permissions`
was built to enforce elsewhere, and this project's own steering-doc rule
against blanket `base.group_user` grants on clinical/billing models.

## Expected vs actual

Expected: role-scoped access matching the rest of the suite (base
internal users get read-only at most; clinic staff get full CRUD via
their actual role group). Actual: unrestricted CRUD for anyone internal.

## Reproduction

Confirmed by inspection: `dental_insurance/security/ir.model.access.csv`
and `dental_lab/security/ir.model.access.csv` each had exactly one row,
group `base.group_user`, `1,1,1,1`.

## Related

Found during the 2026-09-20 full-system audit
(`.odoo-dev/audits/system-audit-2026-09-20.md`, Domain A).
