# Verification — insurance/lab ACL gap

| Check | Result |
|---|---|
| CSV syntax valid (comma count matches header on every row) | **Pass** (visually confirmed both files) |
| New test files compile (`python3 -m py_compile`) | **Pass** |
| `afia_dental_core.group_dental_reception` xmlid exists and is the correct lowest-tier group | **Pass** — confirmed in `afia_dental_core/security/security_groups.xml` |
| Grep for other code assuming `base.group_user`-level (i.e. unrestricted) access to these 4 models | **Pass** — none found outside the two owning modules |

## Pending live verification (Manhel)

1. Upgrade both modules on `db_odoo`.
2. Run `test_access_control.py` in both modules.
3. Manual spot-check: a receptionist/dentist demo account can still
   create/edit a claim and a lab order; a plain internal user (if any
   exists without a clinic group) cannot.

## Status

Fix Implemented — Awaiting Live Verification.
