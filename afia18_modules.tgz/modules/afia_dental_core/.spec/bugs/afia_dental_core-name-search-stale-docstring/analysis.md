# Analysis — stale name_search docstring

## Why not just delete the redundant override

`dental_ux_fixes`'s fast path returns ONLY `patient_no`-matching
partners for a hit; `afia_dental_core`'s fallback (reached via `super()`)
returns `name OR patient_no` matches. These produce IDENTICAL result sets
only if no patient's `name` ever happens to contain the search term as a
substring when that term also matches a `patient_no` — true today given
this system's numeric/sequence-generated `patient_no` format, but not a
guaranteed invariant if that format is ever customized. Silently removing
the override to eliminate the redundant query would change matching
behavior in that edge case without anyone deciding to — exactly the kind
of "lose system intention" risk to avoid per this task's instructions.

## Fix chosen

Correct the docstring to describe CURRENT `afia_dental_core` behavior
accurately, explain why the redundancy exists and is currently harmless,
and explicitly flag the removal option as a decision for Manhel rather
than making it unilaterally. Zero functional change, zero risk.

## Recommendation (not actioned, for Manhel's future decision)

If/when confirmed the `patient_no` format will never overlap with name
substrings (which is true today), the redundant fast-path could be
deleted to save one query per patient-number search. Low priority — the
audit doc rates this Low-Medium severity precisely because the risk is
theoretical, not observed.
