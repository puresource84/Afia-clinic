# Fix — stale name_search docstring

## Changes

- `dental_ux_fixes/models/res_partner_search.py`: rewrote the docstring
  to accurately describe current behavior, preserve the original note
  for historical context, and document the redundancy + removal option
  explicitly rather than silently.
- `dental_ux_fixes/__manifest__.py`: version `18.0.2.2.4` → `18.0.2.2.5`.

No functional code changed — the method body is untouched.

## Rollback

Revert the one comment/docstring edit. Zero risk either direction.

## Deployment

Upgrade `dental_ux_fixes` on `db_odoo` whenever convenient — no urgency,
no behavior change to verify beyond "module still upgrades cleanly."
