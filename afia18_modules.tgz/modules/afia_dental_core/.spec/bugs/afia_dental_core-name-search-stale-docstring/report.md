# Bug Report — stale/inaccurate docstring on a redundant `name_search` override

- **Bug ID**: afia_dental_core-name-search-stale-docstring
- **Status**: Fixed same session (documentation-only)
- **Severity**: Low-Medium
- **Module**: `dental_ux_fixes`
- **Found**: 2026-09-20 system audit, Domain D2

## Issue

`dental_ux_fixes/models/res_partner_search.py`'s `name_search` override
has a docstring describing `afia_dental_core.name_search` as buggy
("forwards `name` to super(), which ANDs an unmatchable display-name
filter... returns nothing") — that was true before the 2026-08-26 fix to
`afia_dental_core`'s own `name_search`, but is factually wrong about the
current code. The override itself is harmless (calls `super()` correctly,
doesn't shadow/break anything) but redundant — it duplicates a
patient_no lookup `afia_dental_core`'s current combined search already
does.

## Decision: documentation fix only, not a functional removal

Removing the redundant fast-path entirely was considered but NOT done —
see `analysis.md` for why it carries a small, real behavioral-equivalence
risk that deserves a deliberate decision rather than an unattended
cleanup.
