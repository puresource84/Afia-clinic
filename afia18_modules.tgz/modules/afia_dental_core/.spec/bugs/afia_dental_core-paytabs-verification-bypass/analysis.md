# Analysis — PayTabs verification bypass

## Root cause

`except Exception: notification_data` was never reassigned to anything
safe — the code just logged a warning and continued using the original,
caller-supplied `notification_data` as if it had been verified.

## Fix

When verification fails (or `tran_ref`/`provider_id` is missing), the
transaction is left/set to `pending` and the function returns — it never
reaches the `raw_status` branch that decides done/error. `_set_pending()`
only transitions transactions currently in `draft` state (confirmed
against Odoo core's `payment.transaction._set_pending`/`_update_state`),
so calling it on an already-`done` transaction (e.g. a duplicate/retried
webhook after a prior successful verification) is a safe no-op, not a
destructive downgrade.

## Why this preserves system intent

PayTabs (like most gateways) retries webhook delivery on failure, and
this module's own `/payment/paytabs/return` controller already calls
`_handle_notification_data` as a second chance when the customer is
redirected back. So a transient verification failure now correctly waits
for a retry instead of either (a) the old bug — trusting unverified data,
or (b) a naive alternative — permanently failing the transaction on a
one-off network blip. No legitimate payment flow is broken; only the
"trust unverified data" fallback is removed.

## Blast radius

Contained to `payment_paytabs`. `payment_zaincash` was checked and does
NOT have this pattern (it fails closed by design already, per its own
TODO-documented dormant state).
