# Fix — PayTabs verification bypass

## Changes

- `payment_paytabs/models/payment_transaction.py`: verification failure
  (or missing `tran_ref`/`provider_id`) now calls `self._set_pending()`
  and returns, instead of proceeding with unverified `notification_data`.
- `payment_paytabs/__manifest__.py`: version `18.0.1.0.2` → `18.0.1.0.3`.
- New `payment_paytabs/tests/test_verification_bypass.py` (module had no
  tests before): proves a forged "approved" callback cannot mark a
  transaction done when verification fails, and confirms the legitimate
  path (verification succeeds) still works.

## Rollback

Revert the one model file + manifest version. No data/schema impact.

## Deployment

1. Upgrade `payment_paytabs` on `db_odoo`.
2. Run the new tests against a disposable DB.
3. If/when this provider goes live with a real merchant account, do one
   real sandbox transaction end-to-end to confirm the happy path still
   completes (verification succeeding → done) — this fix only changes
   the failure path.

## Monitoring

Watch for `PayTabs: server-side verification failed` ERROR log lines in
production — frequent occurrences would indicate a real connectivity
problem with PayTabs worth investigating, now visible for the first time
(previously masked by the silent fallback).
