# Bug Report — PayTabs falls back to unverified callback data

- **Bug ID**: afia_dental_core-paytabs-verification-bypass
- **Status**: Fix implemented same session
- **Severity**: High (payment integrity)
- **Module**: `payment_paytabs`
- **Found**: 2026-09-20 system audit, Domain B1

## Issue

`payment_transaction.py:_process_notification_data()` tried
server-side verification (`_paytabs_verify_transaction`); if that call
raised for ANY reason, it caught broadly and fell back to trusting the
raw, unverified webhook POST body to decide `_set_done()`/`_set_error()`.
A forced or transient verification failure (network blip, PayTabs
downtime, or a deliberate attempt) meant an attacker-influenced payload
could mark a transaction as paid without real server-side confirmation.

## Expected vs actual

Expected: verification failure never results in trusting unverified data
for the payment decision. Actual: it did, exactly the class of bug that
undermines the entire point of server-side verification.

## Reproduction

Confirmed by code inspection; reproduced logically via a unit test that
mocks `_paytabs_verify_transaction` to raise while the raw notification
data claims an approved status — pre-fix, this would mark the TX `done`.
