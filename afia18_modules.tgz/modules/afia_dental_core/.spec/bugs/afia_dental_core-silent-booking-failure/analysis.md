# Analysis — silent booking failure

## Root cause

Both controllers were written defensively against exposing a traceback
to an anonymous public visitor (correct instinct — `auth='public'`
routes must never leak internals), but the defensiveness went one step
too far and dropped server-side visibility too, which was never the
actual goal.

## Fix rationale

Purely additive: one `_logger.exception(...)` call per except block,
same public response as before. No behavior change for the patient, no
risk to the "never expose a traceback publicly" property this code
correctly protects — logging happens server-side, not in the HTTP
response.

## Blast radius

Contained to the two controller files. `dental_booking_slots` extends
`dental_portal_booking`'s controller class and has its OWN separate
`booking_submit` override (the slot-aware path) with its own try/except —
both needed the same fix independently, which is why two files changed.
