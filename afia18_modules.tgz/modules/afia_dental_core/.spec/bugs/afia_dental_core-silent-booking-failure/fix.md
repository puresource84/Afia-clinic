# Fix — silent booking failure

## Changes

- `dental_portal_booking/controllers/main.py`: added `import logging` +
  module logger; `_logger.exception(...)` in `booking_submit`'s except
  block before returning the (unchanged) generic error message.
- `dental_booking_slots/controllers/main.py`: same fix in its own
  `booking_submit` override (the slot-aware path); refactored the create
  vals into a named `booking_vals` variable so the log line can include
  them.
- Version bumps: `dental_portal_booking` 18.0.1.1.0 → 18.0.1.1.1,
  `dental_booking_slots` 18.0.1.0.0 → 18.0.1.0.1.

## Rollback

Revert the two controller files + manifest versions. Zero data impact.

## Deployment

1. Upgrade both modules on `db_odoo`.
2. Manually trigger a booking failure (e.g. temporarily set a required
   field wrong, or submit with an invalid dentist id) and confirm an
   `ERROR`-level traceback now appears in the server log where nothing
   did before.
3. Confirm the public-facing error message is unchanged (no traceback
   leak).

## Monitoring

This is the single highest-leverage change in today's whole audit for
ongoing operations: going forward, watch the log for
`booking_submit failed` entries — every one represents a real patient
who hit a booking error that was previously 100% invisible. If these
start appearing, that's real, actionable signal Manhel didn't have
before today.
