# Bug Report — Public booking forms swallow all errors with no logging

- **Bug ID**: afia_dental_core-silent-booking-failure
- **Status**: Fix implemented same session
- **Severity**: High (business impact — public, revenue-facing channel)
- **Modules**: `dental_portal_booking`, `dental_booking_slots`
- **Found**: 2026-09-20 system audit, Domain C2

## Issue

Both modules' `booking_submit()` controller wraps
`Appointment.create(...)` in `try/except Exception` with **no logging at
all**. Any real failure (data issue, bug, edge case) during a public
patient's online booking attempt is completely invisible server-side —
the patient sees a generic "please call the clinic" message and nothing
is ever recorded. Since this is the clinic's online booking / lead
channel, a silent failure here has direct, invisible business cost.

## Fix

Added `_logger.exception(...)` inside both except blocks, capturing the
patient name/mobile/date and the vals that were attempted, WITHOUT
changing the public-facing behavior at all (still never exposes a
traceback to the visitor — that protection is preserved exactly).
