# CI/CD Notes — afia_dental_core

Per the project's technical-stack steering doc: **there is no CI pipeline
today.** Tests are run manually/ad hoc against the live dev instance. This
file proposes the minimal setup to change that, without assuming
infrastructure this project doesn't have (no GitHub Actions config,
Docker registry, or hosted runner currently in use besides the
self-hosted client Docker Compose file).

## Current state (accept as the baseline, don't assume otherwise)

- "Tests exist and pass locally" is the current bar, not "CI is green."
- The self-hosted distribution repo (`afia-clinic-repo`, public on
  GitHub) has no `.github/workflows/` today.
- `packaging/build_app_store_package.py`'s leak-scan is the closest thing
  to an automated gate that exists in this project, and it only runs on
  demand, not on every commit.

## Minimal proposal, if/when Manhel wants to turn this on

1. **Local pre-push check** (lowest effort, no new infra): a
   `run_tests.ps1`/`run_tests.sh` script in `launch_sprint1_addons/` that
   runs `odoo-bin --test-enable --stop-after-init -i <changed modules>`
   against a scratch DB, for the developer to run by hand before pushing
   to `afia-clinic-repo`. Not automated, but turns "manual, ad hoc" into
   "manual, one command."
2. **GitHub Actions on `afia-clinic-repo`** (next step, real CI): a
   workflow that spins up Postgres + Odoo 18 (official Docker image),
   installs `afia_dental_core` plus whatever module changed, and runs
   `--test-enable`. Gate: PR/push to `main` triggers it, only merge on
   green. This directly protects the public distribution repo real
   clinics install from.
3. **App Store leak-scan as a CI step**, not just a manual pre-build
   command — running `build_app_store_package.py --zip` in CI (against a
   throwaway output dir, not committed) on every push would catch a
   `self_hosted_only` leak the moment it's introduced, rather than at
   next manual build time. This is the cheapest high-value addition given
   the leak-scan logic already exists.

## What this project should NOT do yet

- Don't set a blanket coverage-percentage gate (e.g. "80%") — no coverage
  tooling is configured, and picking a number before knowing the real
  baseline would just produce gamed/meaningless tests to hit it.
- Don't build a multi-Odoo-version test matrix (18.0 only, per steering
  docs) — this isn't an Odoo Apps Store-listed module facing multiple
  supported versions.
- Don't wire this to the private `itcs_license_manager` secret in any CI
  config — CI should test against `launch_sprint1_addons` (the license
  manager's `secret_config.py` there is a real working placeholder secret
  for local dev only) and never touch `afia-clinic-repo`'s intentionally
  secret-less copy in a way that could leak the real value into CI logs.

None of this is implemented — it's a proposal for Manhel to decide on,
not something to build without his sign-off (new infra/workflow files in
the public repo are exactly the kind of change that needs his explicit
go-ahead before committing).
