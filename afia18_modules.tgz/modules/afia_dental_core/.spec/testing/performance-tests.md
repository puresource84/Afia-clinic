# Performance Notes — afia_dental_core

This is a single-clinic, single-tenant self-hosted product per install
(steering docs: the multi-tenant/hosted direction was shelved 2026-07-17).
No load-testing infrastructure exists and building one now would be
over-engineering for the current scale. This file is deliberately light —
a few concrete checks worth doing manually before a clinic goes live with
a real appointment/patient volume, not a perf test harness to build.

## Patterns already done right (verified by reading the code, not measured)

- `res.partner._compute_appointment_count` uses one `_read_group()` for
  the whole recordset instead of a per-record `search_count()` — correct
  batching, no action needed.
- `dental.appointment._compute_time_shifts` batches with one `search()`
  across the whole recordset rather than one per record — same pattern,
  correctly applied.

## Worth a manual check before a clinic's real launch

1. **Calendar sync cost on bulk reschedule.** `_sync_calendar_event` runs
   a `.write()` or `.create()` per record in a loop (`for rec in self`).
   For a normal single-appointment reschedule this is fine; if any future
   feature does a bulk reschedule (e.g. "move all of Dr. X's Tuesday
   appointments"), this becomes N calendar writes instead of one batched
   call. Not a bug today — nothing in the current codebase does bulk
   reschedules — but flag it if `dental_booking_slots` or similar ever
   adds one.
2. **`name_search` on `res.partner`** does a full `search()` with an
   `ilike` OR across `name`/`patient_no` — fine at hundreds/low-thousands
   of patients (typical single clinic), worth an index check
   (`patient_no` already has `index=True`; `name` is indexed by Odoo core)
   if a clinic's patient count grows into the tens of thousands.
3. **`_onboard_new_patients`** does a `search_count()` per
   (patient × active question) pair to avoid duplicate questionnaire rows
   — O(patients × questions). Fine for onboarding a handful of patients
   at a time (the real-world flow), but a bulk import of hundreds of
   patients at once would multiply this out. If bulk patient import ever
   becomes a real feature, switch to one batched existence-check query.

## What NOT to do

Don't add caching, query batching beyond what's above, or async
processing speculatively — there's no evidence of a real performance
problem at the current single-clinic scale, and premature optimization
here would just add maintenance surface for no measured benefit. Revisit
this file if/when the hosted multi-tenant direction is picked back up
(see `dental_pricing_iq`'s deprecation note) — that's the point at which
real load numbers across many clinics will matter.
