# Test Cases — afia_dental_core

Numbered so `test-implementation.md` and future `/odoo-spec-execute` runs
can reference them directly (`TC-01`, `TC-02`, ...). Priority: **P0** =
covers a known gap or candidate defect from `testing-plan.md`; **P1** =
solid regression coverage for existing working behavior; **P2** = edge
case, nice to have.

## dental.appointment

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-01 | P0 | Create appointment with patient+dentist+start_datetime | A linked `calendar.event` is created; its `start`/`stop`/`name` match the appointment. |
| TC-02 | P0 | Reschedule via `write({'start_datetime': ...})` | Linked calendar event's `start`/`stop` update to match; no duplicate event created. |
| TC-03 | P0 | Change `dentist_id` on an existing appointment | Calendar event's `user_id`/`partner_ids` follow the new dentist. |
| TC-04 | P0 | `unlink()` an appointment with a linked calendar event | The calendar event is also deleted (no orphan `calendar.event` left behind). |
| TC-05 | P0 | `action_start()` on a `draft` appointment | Raises `UserError` ("Only confirmed appointments can be started."); state unchanged. |
| TC-06 | P1 | `action_start()` on a `confirmed` appointment | State becomes `in_progress`. |
| TC-07 | P1 | `action_confirm()` / `action_done()` / `action_cancel()` | State transitions as named; no guard on these (verify that's intentional, not a gap). |
| TC-08 | P1 | Create with `duration=0` | `_sql_constraints` `duration_positive` blocks it (IntegrityError). |
| TC-09 | P1 | Create without `appointment_no` | Auto-assigned via `ir.sequence` code `dental.appointment`, not left as `'New'`. |
| TC-10 | P1 | Create with `patient_id` for a partner with no `patient_no` yet | `_ensure_patient_no` backfills it before the appointment is created. |
| TC-11 | P2 | Set `state='cancelled'` then check calendar event | `show_as` becomes `'free'` and `active=False` on the linked event (per `_calendar_event_values`). |
| TC-12 | P2 | `write()` with `appointment_date` but no `start_datetime` | `_shift_start_datetime_to_date` moves the day, keeps time-of-day, in the user's timezone. |
| TC-13 | P1 | `action_open_patient_form()` on a `confirmed` appointment | State flips to `in_progress` as a side effect; returns a `res.partner` form action for the right patient. |

## res.partner (patient extension)

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-14 | P1 | Create partner with `is_patient=False` | No `patient_no` assigned (already covered by existing test — re-verify, don't duplicate). |
| TC-15 | P1 | Create partner with `is_patient=True` | `patient_no` assigned + one `medical.questionnaire` row per active `medical.questions`. |
| TC-16 | P0 | `write({'is_patient': True})` on a partner NOT created as a patient (e.g. auto-flagged from an invoice) | Same onboarding as `create()` runs: `patient_no` backfilled, questionnaire rows seeded — this is the `_sync_patient_flag` entry point from `account.move`; test it from the `res.partner` side directly, not just via an invoice. |
| TC-17 | P1 | `name_search('12345')` where `12345` is a `patient_no`, not a name | Returns the matching patient via the `patient_no` OR clause; result is a list of `(id, display_name)` tuples, never a raw Query/ids list (regression guard for the 2026-08-26 UncaughtPromiseError bug). |
| TC-18 | P1 | `name_search('Dr. Someone')` where the term matches nobody's `patient_no` | Falls through correctly, still returns proper tuples (not the old broken `super()._search()` path). |
| TC-19 | P0 | Call `action_view_appointments()` directly on `afia_dental_core`'s `res.partner` (bypassing `dental_ux_fixes`'s override) | Confirms this copy still works standalone — but see `testing-plan.md` gap #3: this test existing at all is evidence the duplication should be resolved, not just tested. |
| TC-20 | P1 | `action_prescription()` when the patient has zero prior prescriptions | Creates a new draft prescription linked to their latest appointment (or none, if no appointment exists) and returns a form action. |
| TC-21 | P1 | `action_prescription()` when prescriptions already exist | Returns a list view scoped to that patient's existing prescriptions, does NOT create a new one. |

## dental.prescription / dental.prescription_lines

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-22 | P1 | Create prescription, no treatment | `action_create_invoice()` raises `UserError` (already covered — re-verify). |
| TC-23 | P0 | Create prescription + treatment, but company has NO sales journal at all | `_get_treatment_income_account` returns falsy → `action_create_invoice` raises the "No income account configured" `UserError` (this specific branch is currently untested — the existing happy-path test always builds a journal first). |
| TC-24 | P1 | Prescription with `medicine_ids` lines, each linked to a `product.template` with `is_medicine=True` | `action_create_invoice` creates a second `prescription_invoice_id` in addition to the treatment invoice. |
| TC-25 | P2 | Prescription with a `medicine_ids` line whose `medicament_id.product_variant_id` is falsy (no variant) | That line is skipped in `medicine_lines` (per the `if not product: continue` guard) — invoice still created for the remaining lines/treatment. |
| TC-26 | P0 | `write({'next_appointment_date': ...})` when the patient already has an upcoming non-done/cancelled appointment on a DIFFERENT day | The existing appointment is moved (`upcoming.write(...)`), not duplicated. |
| TC-27 | P1 | `write({'next_appointment_date': ...})` when the "upcoming" appointment found is already TODAY | A new separate draft appointment is created instead of moving today's (per the explicit `upcoming.appointment_date != today` guard) — worth confirming this is the intended clinical behavior, not an oversight, since the code comment only says "never touches an appointment already in progress today" but the guard as written also skips reuse for a draft/confirmed appointment merely dated today. |

## account.move (treatment invoice patient sync)

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-28 | P0 | Create an `account.move` with `is_treatment_invoice=True` for a partner where `is_patient=False` | `_sync_patient_flag` flips the partner to `is_patient=True` — this is the direct regression test for the INV/2026/00057 incident; must exist so a future `account.move` refactor can't silently reintroduce it. |
| TC-29 | P1 | Create a normal (non-treatment) invoice for a non-patient partner | Partner remains `is_patient=False` — sync must NOT fire for unrelated invoices. |
| TC-30 | P1 | `write({'is_treatment_invoice': True})` on an existing invoice whose partner isn't a patient | Sync fires on write, not just create. |

## Multi-company / security

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-31 | P0 | User in Company A (no multi-company admin rights) searches `dental.appointment` | Only sees rows where `company_id` is False or in their allowed companies — verify against a Company B appointment created via `sudo()`. |
| TC-32 | P1 | `ir.model.access.csv` baseline (pre-`dental_clinical_permissions` tightening) grants for `dental.prescription`/`medical.questionnaire` | Match what's declared in `afia_dental_core/security/ir.model.access.csv` — this test should assert the *shipped* baseline only; don't assert the tightened values, that belongs to `dental_clinical_permissions`'s own test suite. |

## dental.doctor.invite wizard

| ID | Priority | Case | Expected result |
|----|----|------|------|
| TC-33 | P1 | `action_grant_access()` with a login that doesn't exist yet | Creates a `res.users`, links `employee_id.user_id`, posts a chatter message, sets `state='done'` and a `temp_password`. |
| TC-34 | P1 | `action_grant_access()` with a login that already belongs to another user | Raises `UserError` ("A user with this login already exists."), no user created. |
| TC-35 | P0 | `action_grant_access()` when `action_reset_password()` raises for a reason OTHER than missing SMTP (e.g. simulate with a mock) | Currently silently swallowed by `except Exception: pass` — this test should currently FAIL to prove the gap, then pass once `testing-plan.md` gap #4 is fixed (narrower except + logging). |
