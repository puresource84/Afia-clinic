# Test Implementation — afia_dental_core

Ready-to-drop-in code for the **P0** cases from `test-cases.md` (the ones
covering confirmed gaps, not just regression coverage of already-working
paths). Written as additions to the existing test files, matching their
conventions exactly (`TransactionCase`, `@tagged('post_install',
'-at_install')`, `setUpClass` fixtures, no mocking framework in use
elsewhere in this codebase so plain Python where possible).

Nothing here has been run yet — these are ready to paste in and execute
against a disposable test DB (see `testing-plan.md`), not something to
apply to `launch_sprint1_addons` blind. Run them, see what actually fails,
then decide per-failure whether it's a real bug (`/odoo-bug-create`) or a
test written against a wrong assumption.

## Additions to `tests/test_dental_appointment.py`

```python
# -*- coding: utf-8 -*-
from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestDentalAppointment(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.patient = cls.env['res.partner'].create({
            'name': 'Test Patient',
            'is_patient': True,
        })
        cls.dentist_employee = cls.env['hr.employee'].create({
            'name': 'Dr. Test Dentist',
            'is_dentist': True,
        })

    def _create_appointment(self, **extra):
        vals = {
            'patient_id': self.patient.id,
            'dentist_id': self.dentist_employee.id,
        }
        vals.update(extra)
        return self.env['dental.appointment'].create(vals)

    # -- existing tests unchanged --------------------------------------
    # test_sequence_assigned_on_create, test_patient_no_backfilled_on_create

    # -- TC-01: calendar event created on appointment create -----------
    def test_calendar_event_created_on_create(self):
        appt = self._create_appointment()
        self.assertTrue(appt.calendar_event_id)
        self.assertEqual(appt.calendar_event_id.start, appt.start_datetime)
        self.assertEqual(appt.calendar_event_id.stop, appt.stop_datetime)

    # -- TC-02: reschedule keeps event in sync, doesn't duplicate -------
    def test_calendar_event_synced_on_reschedule(self):
        appt = self._create_appointment()
        original_event = appt.calendar_event_id
        new_start = fields.Datetime.add(appt.start_datetime, hours=3)
        appt.write({'start_datetime': new_start})
        self.assertEqual(appt.calendar_event_id, original_event,
                          'Reschedule must update the existing event, not create a new one.')
        self.assertEqual(appt.calendar_event_id.start, new_start)

    # -- TC-03: dentist change follows through to the calendar event ---
    def test_calendar_event_follows_dentist_change(self):
        appt = self._create_appointment()
        new_dentist = self.env['hr.employee'].create({
            'name': 'Dr. Second', 'is_dentist': True,
        })
        appt.write({'dentist_id': new_dentist.id})
        expected_user = new_dentist.user_id.id if new_dentist.user_id else self.env.uid
        self.assertEqual(appt.calendar_event_id.user_id.id, expected_user)

    # -- TC-04: unlink cascades to the calendar event -------------------
    def test_unlink_removes_calendar_event(self):
        appt = self._create_appointment()
        event = appt.calendar_event_id
        self.assertTrue(event.exists())
        appt.unlink()
        self.assertFalse(event.exists(),
                          'Linked calendar.event must be deleted when the appointment is.')

    # -- TC-05: action_start guard ---------------------------------------
    def test_action_start_requires_confirmed_state(self):
        appt = self._create_appointment()  # default state = draft
        with self.assertRaises(UserError):
            appt.action_start()
        self.assertEqual(appt.state, 'draft')

    def test_action_start_happy_path(self):
        appt = self._create_appointment()
        appt.action_confirm()
        appt.action_start()
        self.assertEqual(appt.state, 'in_progress')
```

Note: add `from odoo import fields` to the file's imports (only
`UserError` and the test base classes are currently imported).

## Addition to `tests/test_res_partner.py`

```python
    # -- TC-16: onboarding runs on write(), not just create() -----------
    def test_onboarding_runs_when_flagged_via_write(self):
        question = self.env['medical.questions'].create({'question': 'Diabetic?'})
        partner = self.env['res.partner'].create({'name': 'Later Patient'})
        self.assertFalse(partner.patient_no)

        partner.write({'is_patient': True})

        self.assertTrue(partner.patient_no,
                         'patient_no must be backfilled when is_patient flips via write(), '
                         'matching the create() path — this is the exact mechanism '
                         'account.move._sync_patient_flag relies on.')
        rows = self.env['medical.questionnaire'].search([('patient_id', '=', partner.id)])
        self.assertIn(question, rows.mapped('question_id'))

    # -- TC-16b: re-flagging an already-patient partner is a no-op ------
    def test_onboarding_not_rerun_for_existing_patient(self):
        patient = self.env['res.partner'].create({'name': 'Already Patient', 'is_patient': True})
        original_no = patient.patient_no
        patient.write({'is_patient': True})  # no-op flip
        self.assertEqual(patient.patient_no, original_no)
```

## New file: `tests/test_account_move_patient_sync.py`

This is the direct regression guard for the INV/2026/00057 incident
(`testing-plan.md` gap #6) — it deserves its own file since it spans two
models and documents a real past production bug.

```python
# -*- coding: utf-8 -*-
from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestAccountMovePatientSync(TransactionCase):
    """Regression guard for the 2026-08-21 INV/2026/00057 incident: a
    treatment invoice for a partner who was never separately created as a
    'Patient' left that partner's is_patient=False, making the invoice
    invisible in every view that filters on partner_id.is_patient=True.
    See afia_dental_core/models/account_move.py and
    migrations/18.0.2.0.5 for the fix and one-time backfill.
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.partner = cls.env['res.partner'].create({'name': 'Not Yet A Patient'})
        company = cls.env.company
        if not company.partner_id.property_account_receivable_id:
            receivable_account = cls.env['account.account'].create({
                'name': 'Test Receivable Account', 'code': '110000',
                'account_type': 'asset_receivable', 'reconcile': True,
                'company_ids': [(6, 0, [company.id])],
            })
            company.partner_id.with_company(company).property_account_receivable_id = receivable_account

    # -- TC-28: create with is_treatment_invoice=True flips the partner -
    def test_treatment_invoice_create_flags_patient(self):
        self.assertFalse(self.partner.is_patient)
        self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'is_treatment_invoice': True,
        })
        self.assertTrue(self.partner.is_patient,
                         'Creating a treatment invoice must auto-flag the partner as a patient.')

    # -- TC-29: a normal invoice must NOT flip the flag ------------------
    def test_normal_invoice_does_not_flag_patient(self):
        self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'is_treatment_invoice': False,
        })
        self.assertFalse(self.partner.is_patient)

    # -- TC-30: flipping is_treatment_invoice via write() also syncs ----
    def test_write_is_treatment_invoice_flags_patient(self):
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
        })
        self.assertFalse(self.partner.is_patient)
        move.write({'is_treatment_invoice': True})
        self.assertTrue(self.partner.is_patient)
```

## New file: `tests/test_multi_company_rule.py`

```python
# -*- coding: utf-8 -*-
from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestAppointmentMultiCompany(TransactionCase):
    """TC-31: rule_dental_appointment_company (afia_dental_core/security/ir_rule.xml)
    must isolate dental.appointment rows by company for non-privileged users."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company_b = cls.env['res.company'].create({'name': 'Branch B'})
        cls.dentist = cls.env['hr.employee'].create({'name': 'Dr. Iso', 'is_dentist': True})
        cls.patient = cls.env['res.partner'].create({'name': 'Iso Patient', 'is_patient': True})

        cls.appt_company_b = cls.env['dental.appointment'].with_company(cls.company_b).create({
            'patient_id': cls.patient.id,
            'dentist_id': cls.dentist.id,
            'company_id': cls.company_b.id,
        })

        # A plain internal user scoped only to the default company —
        # adjust the group here to whatever this project's steering docs
        # define as the lowest-privilege internal role (Receptionist).
        cls.limited_user = cls.env['res.users'].create({
            'name': 'Limited User', 'login': 'limited_user_test',
            'company_id': cls.env.company.id,
            'company_ids': [(6, 0, [cls.env.company.id])],
        })

    def test_appointment_not_visible_across_company(self):
        found = self.env['dental.appointment'].with_user(self.limited_user).search(
            [('id', '=', self.appt_company_b.id)])
        self.assertFalse(found,
                          'A user scoped to the default company must not see '
                          'an appointment whose company_id is a different company.')
```

## Addition to `tests/test_dental_prescription.py`

```python
    # -- TC-23: missing income account path is actually exercised -------
    def test_action_create_invoice_raises_without_income_account(self):
        # Build a prescription+treatment WITHOUT the CoA fixtures this
        # class's own setUpClass creates, by using a brand-new company
        # that has no sales journal/income account configured at all.
        bare_company = self.env['res.company'].create({'name': 'No CoA Co'})
        treatment_category = self.env['treatment.category'].with_company(bare_company).create({
            'name': 'Bare Category',
        })
        treatment = self.env['dental.treatment'].with_company(bare_company).create({
            'name': 'Bare Treatment', 'treatment_categ_id': treatment_category.id, 'cost': 20.0,
        })
        patient = self.env['res.partner'].create({'name': 'Bare Co Patient', 'is_patient': True})
        dentist = self.env['hr.employee'].with_company(bare_company).create({
            'name': 'Dr. Bare', 'is_dentist': True,
        })
        appointment = self.env['dental.appointment'].with_company(bare_company).create({
            'patient_id': patient.id, 'dentist_id': dentist.id, 'company_id': bare_company.id,
        })
        rx = self.env['dental.prescription'].with_company(bare_company).create({
            'appointment_id': appointment.id, 'treatment_id': treatment.id,
        })
        with self.assertRaises(UserError):
            rx.with_company(bare_company).action_create_invoice()
```

## Wizard test: new file `tests/test_doctor_invite.py`

```python
# -*- coding: utf-8 -*-
from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestDoctorInvite(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.employee = cls.env['hr.employee'].create({
            'name': 'Dr. Invite Me', 'is_dentist': True, 'work_email': 'invite.me@example.com',
        })

    def test_grant_access_creates_user(self):
        wizard = self.env['dental.doctor.invite'].create({
            'employee_id': self.employee.id,
            'login': 'invite.me@example.com',
        })
        wizard.action_grant_access()
        self.assertEqual(wizard.state, 'done')
        self.assertTrue(wizard.temp_password)
        self.assertTrue(self.employee.user_id)
        self.assertEqual(self.employee.user_id.login, 'invite.me@example.com')

    def test_grant_access_rejects_duplicate_login(self):
        self.env['res.users'].create({'name': 'Existing', 'login': 'taken@example.com'})
        wizard = self.env['dental.doctor.invite'].create({
            'employee_id': self.employee.id,
            'login': 'taken@example.com',
        })
        with self.assertRaises(UserError):
            wizard.action_grant_access()

    # TC-35 — currently expected to FAIL until testing-plan.md gap #4 is
    # fixed (bare `except Exception: pass` around action_reset_password).
    # Left in as a documented, intentionally-failing test rather than
    # skipped, so it surfaces in the suite output as a to-do, not silence.
    def test_grant_access_does_not_silently_swallow_unexpected_errors(self):
        import unittest
        from unittest.mock import patch

        wizard = self.env['dental.doctor.invite'].create({
            'employee_id': self.employee.id,
            'login': 'invite.me@example.com',
        })
        with patch(
            'odoo.addons.base.models.res_users.Users.action_reset_password',
            side_effect=RuntimeError('simulated unrelated failure'),
        ):
            with self.assertRaises(RuntimeError):
                wizard.action_grant_access()
```

## Running these

```bash
# from the Odoo server directory, against a disposable DB:
odoo-bin -d afia_test --test-enable --stop-after-init \
  -i afia_dental_core --test-tags afia_dental_core
```

Expect `test_grant_access_does_not_silently_swallow_unexpected_errors` to
FAIL on first run (that's the point — it documents gap #4). Everything
else is expected to pass; any other failure is either a real bug worth a
`/odoo-bug-create`, or a wrong assumption in the test worth fixing.
