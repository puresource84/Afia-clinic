# Test Plan — afia_dental_core

Foundation module (the only `application: True` entry point; every other Afia
Clinic module depends on it directly or indirectly). Bugs here have the
widest blast radius in the suite, so this is the highest-value module to
test first.

## Scope

Models covered: `dental.appointment`, `res.partner` (patient extension),
`dental.prescription` / `dental.prescription_lines`, `account.move`
(treatment-invoice patient sync), `account.payment`, `dental.treatment`,
`dental.specialist`, `dental.time.shift`, `medical.questionnaire`,
`hr.employee` (dentist extension), the `dental.doctor.invite` wizard, and
`ir_rule.xml` multi-company isolation.

Out of scope for this pass: companion modules that merely *depend on*
these models (`dental_charting_pro`, `dental_treatment_plan`, etc.) — each
gets its own `/odoo-module-test` pass later.

## Test database & tooling

- Use a disposable test DB, never `db_odoo` (the live dev/demo instance).
  `odoo-bin -d afia_test --test-enable --stop-after-init -i afia_dental_core`
  or `pytest-odoo` with `--odoo-database=afia_test`.
- Fresh test DBs have **no chart of accounts** — any test touching
  `account.move`/`action_create_invoice` must build a minimal CoA itself
  (see the existing pattern in `tests/test_dental_prescription.py`
  `setUpClass`) rather than assuming demo data exists.
- Existing suite already uses `TransactionCase` + `@tagged('post_install',
  '-at_install')` — keep new tests in that style so they run together.
- No CI pipeline runs these today (confirmed in steering docs) — this is a
  manual/local gate until one exists. See `ci-cd-integration.md` for a
  proposed minimal setup.

## What's already covered (existing tests, read before writing new ones)

- `test_dental_appointment.py`: sequence number assignment, patient_no
  backfill safety net. **Nothing else** — no coverage of state transitions,
  calendar sync, or unlink cascade, despite this being the busiest model
  in the module.
- `test_res_partner.py`: patient_no scoping, questionnaire auto-seed,
  batched appointment_count, age computation.
- `test_dental_prescription.py`: sequence assignment, patient/doctor
  follow appointment, follow-up appointment creation, `action_prescribed`
  state sync, invoice creation happy path + missing-treatment guard.

## Known coverage gaps / candidate defects found during this review

These are **not confirmed bugs** — they're untested code paths with a
plausible failure mode, worth a deliberate test (and a `/odoo-bug-create`
if the test proves the bug out):

1. **`dental.appointment.action_start`** raises `UserError` unless
   `state == 'confirmed'` — no test ever exercises the guard or the happy
   path transition `confirmed → in_progress`.
2. **Calendar sync (`_sync_calendar_event`)** is the entire rationale for
   the 2026-08 clean-room rewrite ("real calendar.event... instead of a
   bespoke date field") but has zero test coverage: no test verifies a
   `calendar.event` is actually created, kept in sync on
   reschedule/dentist-change, or removed on `unlink()`.
3. **`res.partner.action_view_appointments` has two independent
   implementations** — this one, and a non-`super()`-calling override in
   `dental_ux_fixes/models/res_partner_smart_buttons.py` that wins because
   it loads later. The code comment admits they can drift ("if you change
   one, change both"). This is a structural risk, not just a missing
   test — worth a `/odoo-bug-create` on its own to either delete the dead
   copy here or make the override call `super()`.
4. **`dental.doctor.invite.action_grant_access`** swallows *any* exception
   from `action_reset_password()` with a bare `except Exception: pass`.
   If SMTP is misconfigured, the clinic admin sees "Done" with a shown
   temp password (the intended fallback) — that part is fine — but any
   *other* unrelated failure in the reset-password flow (e.g. a data
   error) is silently hidden the same way, with no log trace. Worth
   narrowing the except clause and/or logging.
5. **Multi-company isolation** (`ir_rule.xml`'s
   `rule_dental_appointment_company`) has no automated test proving a
   non-manager user in Company A cannot read/write Company B's
   appointments.
6. **`account.move._sync_patient_flag`** (the INV/2026/00057 self-healing
   fix) has no regression test — a future refactor of `account.move`
   could silently reintroduce the original bug (treatment invoices
   invisible because the partner was never flagged `is_patient`).
7. **`dental.prescription._get_treatment_income_account`** raising
   `UserError` when no sales journal/income account exists is only
   exercised implicitly via the CoA the test itself builds — the actual
   "not configured" `UserError` path is never hit in tests.

## Test categories

- **Unit** — constraints (`duration_positive`), computed fields (`stop_datetime`,
  `appointment_date`, `patient_age`, `appointment_count`, `medical_alert_summary`),
  onchange-equivalent behavior via `write()`, CRUD guards, exception paths.
- **Integration** — cross-model: appointment ↔ calendar.event sync,
  prescription ↔ appointment ↔ invoice chain, patient onboarding ↔
  medical questionnaire seeding, treatment invoice ↔ `is_patient` sync.
- **Security** — `ir.model.access.csv` per role (see `dental_clinical_permissions`
  steering notes — that module tightens several of this module's default
  grants; a permissions test here should assert the *pre-tightening*
  baseline only, not duplicate that module's own security tests).
- **Multi-company** — record rule isolation for `dental.appointment`.
- **Migration** — `migrations/18.0.2.0.2` and `18.0.2.0.5` post-migrate
  scripts are one-time data fixes; not re-tested per run, but worth a
  smoke check that they're idempotent if re-run accidentally.

Performance and CI/CD notes are in the separate files in this folder.
