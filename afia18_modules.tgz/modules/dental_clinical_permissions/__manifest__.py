# -*- coding: utf-8 -*-
{'name': 'Dental Permissions',
 'version': '18.0.1.4.7',
 'category': 'Healthcare/Dental',
 'summary': 'Role-based access matrix — clinical records are locked to clinical roles; billing '
            'locked to admin roles.',
 'description': 'Dental Clinical Permissions\n'
                '===========================\n'
                'Enforces a strict role matrix across the Afia Clinic suite.\n'
                '\n'
                'Roles\n'
                '-----\n'
                '- Clinic Manager — full access to all records and configuration\n'
                '- Dentist / Clinician — read-write on clinical records; read-only on billing\n'
                '- Hygienist — clinical notes and charting only; no prescriptions\n'
                '- Receptionist — appointments and patient demographics; no clinical records\n'
                '- Lab Technician — lab orders only\n'
                '- Billing Admin — invoices, insurance claims, payments; no clinical records\n'
                '\n'
                'Features\n'
                '--------\n'
                '- Record rules applied at the model level (not just menu hiding)\n'
                '- Audit log of permission changes\n'
                '- Conflict checker — warns if a user has conflicting roles\n'
                '\n'
                'Requires clinic_core for base group definitions.\n',
 'author': 'ITCS (IT Corner Solutions)',
 'website': 'https://www.itcornersolutions.net/',
 'license': 'OPL-1',
 'depends': ['afia_dental_core',
             'dental_charting',
             'dental_treatment_plan',
             'dental_consent',
             'stock',
             'hr',
             'account',
             'mail'],
 'data': ['security/security_groups.xml',
          'security/ir.model.access.csv',
          'security/access_overrides.xml',
          'views/xray_report_views.xml',
          'views/res_partner_views.xml',
          'data/ir_cron_reapply_access_overrides.xml',
          'views/login_form_visibility_fix.xml',
          'wizards/clinic_user_wizard_views.xml',
          'views/res_users_staff_views.xml'],
 'images': ['static/description/icon.png'],
 'installable': True,
 'application': False,
 'post_init_hook': 'post_init_hook',
 'price': 0,
 'currency': 'USD'}
